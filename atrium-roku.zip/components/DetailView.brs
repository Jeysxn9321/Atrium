' A title page: picture, story, Play / Continue, and for a series its seasons and episodes.

sub init()
    m.acts = m.top.findNode("acts")
    m.seasons = m.top.findNode("seasons")
    m.eps = m.top.findNode("eps")
    m.status = m.top.findNode("status")
    m.acts.observeField("itemSelected", "onAct")
    m.seasons.observeField("itemFocused", "onSeasonFocus")
    m.eps.observeField("itemSelected", "onEpisode")
    m.loadedId = ""
    m.meta = invalid
    m.resume = invalid
end sub

sub onActive()
    if not m.top.active then return
    it = m.top.item
    if it = invalid then return
    if m.loadedId = it.id
        focusMain()
        return
    end if
    m.loadedId = it.id
    m.meta = invalid
    m.resume = invalid
    if it.videoId <> invalid and it.offset <> invalid then m.resume = { videoId: it.videoId, offset: it.offset, duration: it.duration }
    m.top.findNode("name").text = it.name
    m.top.findNode("poster").uri = it.poster
    m.top.findNode("backdrop").uri = ""
    m.top.findNode("facts").text = ""
    m.top.findNode("about").text = ""
    m.seasons.visible = false
    m.eps.visible = false
    m.status.visible = true
    m.status.text = "Loading..."
    buildActions()
    m.metaTask = CreateObject("roSGNode", "ApiTask")
    m.metaTask.op = "meta"
    m.metaTask.args = { type: it.type, id: it.id }
    m.metaTask.observeField("result", "onMeta")
    m.metaTask.control = "RUN"
    m.acts.setFocus(true)
end sub

sub focusMain()
    m.acts.setFocus(true)
end sub

sub onProgress()
    p = m.top.progress
    if p = invalid then return
    if p.dur = invalid or p.dur <= 0 then return
    ' the player reports where it stopped (seconds); 0 means finished or never really started
    if p.pos > 30 and p.dur > 0 and (p.pos / p.dur) < 0.92
        m.resume = { videoId: p.videoId, offset: p.pos * 1000, duration: p.dur * 1000 }
    else
        m.resume = invalid
    end if
    buildActions()
end sub

sub onMeta(ev as object)
    if not ev.getRoSGNode().isSameNode(m.metaTask) then return
    r = ev.getData()
    m.status.visible = false
    if r = invalid or r.meta = invalid
        m.loadedId = ""
        m.status.visible = true
        m.status.text = "Could not load the details (you can still play it)."
        return
    end if
    m.meta = r.meta
    facts = ""
    for each x in [r.meta.year, r.meta.runtime, r.meta.rating]
        if x <> "" then
            if facts <> "" then facts = facts + "   |   "
            facts = facts + x
        end if
    end for
    if r.meta.rating <> "" then facts = facts + "  (IMDb)"
    m.top.findNode("facts").text = facts
    m.top.findNode("about").text = r.meta.description
    if r.meta.background <> "" then m.top.findNode("backdrop").uri = r.meta.background
    if m.top.item.type = "series" then buildSeasons()
    buildActions()
end sub

function firstEpisode() as object
    if m.meta = invalid or m.meta.videos.Count() = 0 then return invalid
    best = m.meta.videos[0]
    for each v in m.meta.videos
        if v.season < best.season or (v.season = best.season and v.episode < best.episode) then best = v
    end for
    return best
end function

function episodeLabel(videoId as string) as string
    if m.meta <> invalid
        for each v in m.meta.videos
            if v.id = videoId then return "S" + v.season.ToStr() + " E" + v.episode.ToStr()
        end for
    end if
    parts = videoId.Split(":")
    if parts.Count() = 3 then return "S" + parts[1] + " E" + parts[2]
    return ""
end function

sub buildActions()
    it = m.top.item
    m.actions = []
    if it.type = "movie"
        if m.resume <> invalid
            m.actions.Push({ label: "Resume from " + formatClock(Int(m.resume.offset / 1000)), kind: "resume" })
            m.actions.Push({ label: "Start over", kind: "start" })
        else
            m.actions.Push({ label: "Play", kind: "start" })
        end if
    else
        if m.resume <> invalid
            m.actions.Push({ label: "Continue " + episodeLabel(m.resume.videoId) + " from " + formatClock(Int(m.resume.offset / 1000)), kind: "resume" })
        else
            fe = firstEpisode()
            if fe <> invalid then m.actions.Push({ label: "Play S" + fe.season.ToStr() + " E" + fe.episode.ToStr(), kind: "first" })
        end if
        if m.meta <> invalid and m.meta.videos.Count() > 0 then m.actions.Push({ label: "Choose an episode", kind: "choose" })
    end if
    root = CreateObject("roSGNode", "ContentNode")
    for each a in m.actions
        c = CreateObject("roSGNode", "ContentNode")
        c.title = a.label
        root.appendChild(c)
    end for
    m.acts.content = root
    m.acts.numRows = m.actions.Count()
    if m.actions.Count() = 0 then m.acts.numRows = 1
end sub

sub buildSeasons()
    nums = []
    for each v in m.meta.videos
        found = false
        for each n in nums
            if n = v.season then found = true
        end for
        if not found then nums.Push(v.season)
    end for
    ' ascending
    for i = 1 to nums.Count() - 1
        cur = nums[i]
        j = i - 1
        while j >= 0 and nums[j] > cur
            nums[j + 1] = nums[j]
            j = j - 1
        end while
        nums[j + 1] = cur
    end for
    m.seasonNums = nums
    root = CreateObject("roSGNode", "ContentNode")
    for each n in nums
        c = CreateObject("roSGNode", "ContentNode")
        c.title = "Season " + n.ToStr()
        root.appendChild(c)
    end for
    m.seasons.content = root
    m.seasons.visible = nums.Count() > 0
    m.eps.visible = nums.Count() > 0
    if nums.Count() > 0 then showEpisodes(nums[0])
end sub

sub showEpisodes(season as integer)
    list = []
    for each v in m.meta.videos
        if v.season = season then list.Push(v)
    end for
    for i = 1 to list.Count() - 1
        cur = list[i]
        j = i - 1
        while j >= 0 and list[j].episode > cur.episode
            list[j + 1] = list[j]
            j = j - 1
        end while
        list[j + 1] = cur
    end for
    m.epList = list
    root = CreateObject("roSGNode", "ContentNode")
    for each v in list
        c = CreateObject("roSGNode", "ContentNode")
        t = v.episode.ToStr() + ".  " + v.title
        c.title = t
        root.appendChild(c)
    end for
    m.eps.content = root
end sub

sub onSeasonFocus()
    if m.seasonNums = invalid then return
    i = m.seasons.itemFocused
    if i >= 0 and i < m.seasonNums.Count() then showEpisodes(m.seasonNums[i])
end sub

sub playVideo(videoId as string, startAt as integer)
    it = m.top.item
    m.top.action = { kind: "play", type: it.type, id: videoId, root: it.id, name: it.name, poster: it.poster, startAt: startAt }
end sub

sub onAct()
    i = m.acts.itemSelected
    if i < 0 or i >= m.actions.Count() then return
    k = m.actions[i].kind
    it = m.top.item
    if k = "start"
        playVideo(it.id, 0)
    else if k = "resume"
        playVideo(m.resume.videoId, Int(m.resume.offset / 1000))
    else if k = "first"
        playVideo(firstEpisode().id, 0)
    else if k = "choose"
        m.eps.setFocus(true)
    end if
end sub

sub onEpisode()
    i = m.eps.itemSelected
    if m.epList = invalid or i < 0 or i >= m.epList.Count() then return
    v = m.epList[i]
    start = 0
    if m.resume <> invalid and m.resume.videoId = v.id then start = Int(m.resume.offset / 1000)
    playVideo(v.id, start)
end sub

function onKeyEvent(key as string, press as boolean) as boolean
    if not press then return false
    if key = "back"
        if m.eps.hasFocus() or m.seasons.hasFocus()
            m.acts.setFocus(true)
            return true
        end if
        m.top.action = { kind: "back" }
        return true
    else if key = "right" and m.seasons.hasFocus()
        m.eps.setFocus(true)
        return true
    else if key = "left" and m.eps.hasFocus()
        m.seasons.setFocus(true)
        return true
    else if key = "down" and m.acts.hasFocus() and m.seasons.visible
        m.seasons.setFocus(true)
        return true
    else if key = "up" and (m.seasons.hasFocus() or m.eps.hasFocus())
        m.acts.setFocus(true)
        return true
    end if
    return false
end function
