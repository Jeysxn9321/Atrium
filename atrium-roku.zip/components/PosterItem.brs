sub onContent()
    c = m.top.itemContent
    if c = invalid then return
    m.top.findNode("poster").uri = c.HDPosterUrl
    m.top.findNode("name").text = c.title
end sub

sub onSize()
    w = m.top.width
    h = m.top.height
    if w <= 0 or h <= 0 then return
    for each id in ["back", "poster"]
        n = m.top.findNode(id)
        n.width = w
        n.height = h
    end for
    n = m.top.findNode("name")
    n.width = w - 16
    n.height = h - 16
end sub
