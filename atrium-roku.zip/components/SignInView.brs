sub init()
    m.code = m.top.findNode("code")
    m.status = m.top.findNode("status")
end sub

sub onActive()
    if not m.top.active then
        if m.task <> invalid then m.task.control = "STOP"
        return
    end if
    m.top.setFocus(true)
    m.task = CreateObject("roSGNode", "AuthTask")
    m.task.observeField("code", "onCode")
    m.task.observeField("status", "onStatus")
    m.task.observeField("result", "onResult")
    m.task.control = "RUN"
end sub

sub onCode()
    c = m.task.code
    if Len(c) = 8 then m.code.text = Left(c, 4) + "  -  " + Mid(c, 5)
end sub

sub onStatus()
    m.status.text = m.task.status
end sub

sub onResult()
    r = m.task.result
    if r = invalid or r.key = invalid then return
    regWrite("stremioKey", r.key)
    m.status.text = "Signed in."
    m.top.signedIn = true
end sub
