' One background request for the screens: set op and args, run the task, read result.
'   library   -> { items: [...] } | { error, auth }      the Stremio library
'   catalog   -> { metas: [...] }                         args { type, cat }
'   meta      -> { meta: {...} }                          args { type, id }
'   streams   -> { streams: [...] } | { error }           args { type, id }
'   progress  -> { ok }                                   args { type, videoId, root, name, poster, pos, dur }

sub init()
    m.top.functionName = "runOp"
end sub

sub runOp()
    op = m.top.op
    a = m.top.args
    if a = invalid then a = {}
    if op = "library"
        m.top.result = opLibrary()
    else if op = "catalog"
        m.top.result = opCatalog(a)
    else if op = "meta"
        m.top.result = opMeta(a)
    else if op = "streams"
        m.top.result = opStreams(a)
    else if op = "progress"
        m.top.result = opProgress(a)
    else
        m.top.result = { error: "unknown request" }
    end if
end sub

function authKey() as string
    return regRead("stremioKey")
end function

function opLibrary() as object
    key = authKey()
    if key = "" then return { error: "not signed in", auth: true }
    j = stremioCall("datastoreGet", { authKey: key, collection: "libraryItem", ids: [], all: true })
    if j = invalid then return { error: "no answer" }
    if j.error <> invalid
        msg = LCase(asString(j.error.message))
        bad = (Instr(1, msg, "session") > 0) or (Instr(1, msg, "auth") > 0) or (Instr(1, msg, "token") > 0) or (Instr(1, msg, "logged") > 0)
        return { error: asString(j.error.message), auth: bad }
    end if
    items = []
    if j.result <> invalid
        for each x in j.result
            if type(x) = "roAssociativeArray" and Left(asString(x._id), 2) = "tt" and (x.type = "movie" or x.type = "series")
                it = { id: x._id, type: x.type, name: asString(x.name), poster: asString(x.poster), mtime: asString(x._mtime), removed: (x.removed = true), temp: (x.temp = true) }
                if type(x.state) = "roAssociativeArray"
                    it.videoId = asString(x.state.video_id)
                    it.offset = x.state.timeOffset
                    it.duration = x.state.duration
                    it.lastWatched = asString(x.state.lastWatched)
                end if
                items.Push(it)
            end if
        end for
    end if
    return { items: items }
end function

function opCatalog(a as object) as object
    j = getJson("https://v3-cinemeta.strem.io/catalog/" + asString(a.type) + "/" + asString(a.cat) + ".json")
    if j = invalid or j.metas = invalid then return { error: "no answer" }
    metas = []
    for each x in j.metas
        if type(x) = "roAssociativeArray" and x.id <> invalid
            metas.Push({ id: x.id, type: asString(a.type), name: asString(x.name), poster: asString(x.poster) })
        end if
    end for
    return { metas: metas }
end function

function opMeta(a as object) as object
    j = getJson("https://v3-cinemeta.strem.io/meta/" + asString(a.type) + "/" + asString(a.id) + ".json")
    if j = invalid or j.meta = invalid then return { error: "no answer" }
    x = j.meta
    videos = []
    if x.videos <> invalid
        for each v in x.videos
            if type(v) = "roAssociativeArray" and v.id <> invalid and v.season <> invalid and v.season > 0 and v.episode <> invalid
                t = asString(v.name)
                if t = "" then t = asString(v.title)
                videos.Push({ id: v.id, season: v.season, episode: v.episode, title: t })
            end if
        end for
    end if
    return { meta: {
        id: asString(a.id), type: asString(a.type), name: asString(x.name), description: asString(x.description),
        year: asString(x.releaseInfo), runtime: asString(x.runtime), rating: asString(x.imdbRating),
        background: asString(x.background), poster: asString(x.poster), videos: videos
    } }
end function

' The address of your own Torrentio add-on (the one set up with TorBox), read from the Stremio account.
function findTorrentio(key as string) as string
    j = stremioCall("addonCollectionGet", { authKey: key, update: true })
    if j = invalid or j.result = invalid or j.result.addons = invalid then return ""
    pick = ""
    for each ad in j.result.addons
        u = asString(ad.transportUrl)
        if Left(u, 8) = "https://" and Instr(1, LCase(u), "torrentio") > 0
            u = replaceAll(u, "/manifest.json", "")
            u = replaceAll(u, "|", "%7C")
            if Instr(1, LCase(u), "torbox") > 0 then return u
            if pick = "" then pick = u
        end if
    end for
    return pick
end function

function opStreams(a as object) as object
    key = authKey()
    if key = "" then return { error: "not signed in" }
    base = findTorrentio(key)
    if base = "" then return { error: "No Torrentio add-on was found in your Stremio account." }
    j = getJson(base + "/stream/" + asString(a.type) + "/" + asString(a.id) + ".json")
    if j = invalid then return { error: "Torrentio did not answer." }
    if j.streams = invalid then return { error: "No stream found for this one." }
    list = pickStreams(j.streams, 5)
    if list.Count() = 0 then return { error: "No stream found for this one." }
    return { streams: list }
end function

function opProgress(a as object) as object
    key = authKey()
    if key = "" then return { ok: false }
    root = asString(a.root)
    videoId = asString(a.videoId)
    if root = "" then return { ok: false }
    posn = a.pos
    dur = a.dur
    if posn = invalid then posn = 0
    if dur = invalid then dur = 0
    offset = Int(posn * 1000)
    if dur > 0 and posn / dur > 0.92 then offset = 0
    now = isoNow()
    got = stremioCall("datastoreGet", { authKey: key, collection: "libraryItem", ids: [root], all: false })
    old = invalid
    if got <> invalid and got.result <> invalid
        for each x in got.result
            if type(x) = "roAssociativeArray" and x._id = root then old = x
        end for
    end if
    item = invalid
    if old <> invalid and type(old.state) = "roAssociativeArray"
        item = old
        item._mtime = now
        item.state.lastWatched = now
        item.state.video_id = videoId
        item.state.timeOffset = offset
        item.state.duration = Int(dur * 1000)
    else if old = invalid and got <> invalid and got.result <> invalid
        item = {
            _id: root, name: asString(a.name), type: asString(a.type), poster: asString(a.poster), posterShape: "poster", removed: true, temp: true,
            _ctime: now, _mtime: now,
            state: { lastWatched: now, timeWatched: Int(posn * 1000), timeOffset: offset, overallTimeWatched: 0, timesWatched: 0, flaggedWatched: 0, duration: Int(dur * 1000), video_id: videoId, watched: "", noNotif: false },
            behaviorHints: { defaultVideoId: invalid, featuredVideoId: invalid, hasScheduledVideos: false }
        }
    end if
    if item = invalid then return { ok: false }
    r = stremioCall("datastorePut", { authKey: key, collection: "libraryItem", changes: [item] })
    return { ok: (r <> invalid) }
end function
