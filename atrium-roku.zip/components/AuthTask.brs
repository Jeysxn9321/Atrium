' Signing in with a code: the TV shows a code, the phone (Atrium, gear, "Sign in a TV") sends the Stremio sign-in
' encrypted with it through ntfy.sh, and this task picks it up.

sub init()
    m.top.functionName = "runAuth"
end sub

function newCode() as string
    chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"
    di = CreateObject("roDeviceInfo")
    hex = replaceAll(di.GetRandomUUID(), "-", "")
    code = ""
    for i = 0 to 7
        b = Val(Mid(hex, i * 2 + 1, 2), 16)
        code = code + Mid(chars, (b mod 32) + 1, 1)
    end for
    return code
end function

sub runAuth()
    while true
        code = newCode()
        m.top.code = code
        m.top.status = "Preparing a secure code..."
        keys = atriumDeriveKeys(code)
        m.top.status = "Waiting for your phone..."
        timer = CreateObject("roTimespan")
        while timer.TotalSeconds() < 900
            key = pollOnce(keys)
            if key <> ""
                m.top.result = { key: key }
                return
            end if
            sleep(3000)
        end while
    end while
end sub

function pollOnce(keys as object) as string
    r = httpRequest("https://ntfy.sh/" + keys.topic + "/json?poll=1&since=all", "GET", "", invalid, 15000)
    if r.code <> 200 then return ""
    lines = r.body.Split(Chr(10))
    for i = lines.Count() - 1 to 0 step -1
        if Len(lines[i]) > 2
            j = ParseJson(lines[i])
            if j <> invalid and j.event = "message" and j.message <> invalid
                pt = atriumDecrypt(asString(j.message), keys)
                if pt <> ""
                    p = ParseJson(pt)
                    if p <> invalid and p.k <> invalid and Len(asString(p.k)) > 10 then return asString(p.k)
                end if
            end if
        end if
    end for
    return ""
end function
