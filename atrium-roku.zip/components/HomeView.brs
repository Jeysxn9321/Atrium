' The home screen: rows of posters. Continue watching and My list come from the Stremio library, the others from Cinemeta.

sub init()
    m.rows = m.top.findNode("rows")
    m.focusName = m.top.findNode("focusName")
    m.status = m.top.findNode("status")
    m.rows.observeField("rowItemSelected", "onSelected")
    m.rows.observeField("rowItemFocused", "onFocused")
    m.cont = []
    m.mylist = []
    m.movies = []
    m.series = []
    m.lib = {}
    m.table = []
    m.loaded = false
end sub

sub onActive()
    if not m.top.active then return
    if m.keyUsed <> regRead("stremioKey")
        m.keyUsed = regRead("stremioKey")
        m.loaded = false
        m.cont = []
        m.mylist = []
        m.lib = {}
        m.rows.content = invalid
    end if
    m.rows.setFocus(true)
    if not m.loaded then m.status.text = "Loading..."
    m.libTask = CreateObject("roSGNode", "ApiTask")
    m.libTask.op = "library"
    m.libTask.observeField("result", "onLibrary")
    m.libTask.control = "RUN"
    if not m.loaded
        m.movTask = CreateObject("roSGNode", "ApiTask")
        m.movTask.op = "catalog"
        m.movTask.args = { type: "movie", cat: "top" }
        m.movTask.observeField("result", "onMovies")
        m.movTask.control = "RUN"
        m.serTask = CreateObject("roSGNode", "ApiTask")
        m.serTask.op = "catalog"
        m.serTask.args = { type: "series", cat: "top" }
        m.serTask.observeField("result", "onSeries")
        m.serTask.control = "RUN"
    end if
end sub

function posterFor(it as object) as string
    if it.poster <> invalid and it.poster <> "" then return it.poster
    return "https://images.metahub.space/poster/medium/" + it.id + "/img"
end function

sub onLibrary()
    r = m.libTask.result
    if r = invalid then return
    if r.error <> invalid
        if r.auth = true
            m.top.signOutAsked = true
        else if not m.loaded
            m.status.text = "Could not reach your Stremio library (" + r.error + ")."
        end if
        return
    end if
    m.lib = {}
    cont = []
    mylist = []
    for each it in r.items
        m.lib[it.id] = it
        if it.removed <> true and it.temp <> true then mylist.Push(it)
        if it.offset <> invalid and it.duration <> invalid and it.duration > 0 and it.offset > 0 and (it.offset / it.duration) < 0.92 then cont.Push(it)
    end for
    ' newest watched first
    n = cont.Count()
    for i = 1 to n - 1
        cur = cont[i]
        j = i - 1
        while j >= 0 and cont[j].lastWatched < cur.lastWatched
            cont[j + 1] = cont[j]
            j = j - 1
        end while
        cont[j + 1] = cur
    end for
    m.cont = cont
    m.mylist = mylist
    rebuild()
end sub

sub onMovies()
    r = m.movTask.result
    if r <> invalid and r.metas <> invalid then m.movies = r.metas
    rebuild()
end sub

sub onSeries()
    r = m.serTask.result
    if r <> invalid and r.metas <> invalid then m.series = r.metas
    rebuild()
end sub

function addRow(root as object, title as string, items as object) as boolean
    if items.Count() = 0 then return false
    row = CreateObject("roSGNode", "ContentNode")
    row.title = title
    list = []
    for each it in items
        c = CreateObject("roSGNode", "ContentNode")
        c.title = it.name
        c.HDPosterUrl = posterFor(it)
        row.appendChild(c)
        list.Push(it)
    end for
    root.appendChild(row)
    m.table.Push(list)
    return true
end function

sub rebuild()
    ' keep the place on screen when the rows are rebuilt
    keepRow = 0
    keepCol = 0
    if m.loaded
        f = m.rows.rowItemFocused
        if f <> invalid and f.Count() = 2
            keepRow = f[0]
            keepCol = f[1]
        end if
    end if
    root = CreateObject("roSGNode", "ContentNode")
    m.table = []
    addRow(root, "Continue watching", m.cont)
    addRow(root, "My list", m.mylist)
    addRow(root, "Popular movies", m.movies)
    addRow(root, "Popular series", m.series)
    if m.table.Count() = 0 then return
    m.status.text = ""
    m.rows.content = root
    m.loaded = true
    if keepRow < m.table.Count() then
        if keepCol >= m.table[keepRow].Count() then keepCol = 0
        m.rows.jumpToRowItem = [keepRow, keepCol]
    end if
    if m.top.active then m.rows.setFocus(true)
end sub

sub onFocused()
    f = m.rows.rowItemFocused
    if f = invalid or f.Count() <> 2 then return
    if f[0] < m.table.Count() and f[1] < m.table[f[0]].Count() then m.focusName.text = m.table[f[0]][f[1]].name
end sub

sub onSelected()
    f = m.rows.rowItemSelected
    if f = invalid or f.Count() <> 2 then return
    if f[0] >= m.table.Count() or f[1] >= m.table[f[0]].Count() then return
    it = m.table[f[0]][f[1]]
    picked = { id: it.id, type: it.type, name: it.name, poster: posterFor(it) }
    lib = m.lib[it.id]
    if lib <> invalid and lib.offset <> invalid and lib.duration <> invalid and lib.duration > 0 and lib.offset > 0 and (lib.offset / lib.duration) < 0.92
        picked.videoId = lib.videoId
        picked.offset = lib.offset
        picked.duration = lib.duration
    end if
    m.top.picked = picked
end sub

function onKeyEvent(key as string, press as boolean) as boolean
    if press and key = "options"
        d = CreateObject("roSGNode", "StandardMessageDialog")
        d.title = "Atrium"
        d.message = ["Sign out of this TV?", "You can sign in again with a code from your phone."]
        d.buttons = ["Sign out", "Cancel"]
        d.observeFieldScoped("buttonSelected", "onDialog")
        d.observeFieldScoped("wasClosed", "onDialogClosed")
        m.dialog = d
        m.top.getScene().dialog = d
        return true
    end if
    return false
end function

sub onDialogClosed()
    m.top.getScene().dialog = invalid
    m.rows.setFocus(true)
end sub

sub onDialog()
    idx = m.dialog.buttonSelected
    m.top.getScene().dialog = invalid
    if idx = 0 then m.top.signOutAsked = true
    m.rows.setFocus(true)
end sub
