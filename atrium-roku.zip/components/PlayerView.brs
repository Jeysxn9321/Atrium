' Playing a title: get the versions from Torrentio, try the best one, and move to the next if it fails or never starts.
' Where you stopped is saved to the Stremio library, so Continue watching works on every device.

sub init()
    m.vid = m.top.findNode("vid")
    m.msg = m.top.findNode("msg")
    m.stall = m.top.findNode("stall")
    m.saver = m.top.findNode("saver")
    m.vid.observeField("state", "onState")
    m.vid.observeField("position", "onPosition")
    m.vid.observeField("duration", "onDuration")
    m.stall.observeField("fire", "onStall")
    m.saver.observeField("fire", "onSaveTick")
    m.list = []
    m.idx = 0
    m.pos = 0
    m.dur = 0
    m.started = false
end sub

sub onActive()
    if not m.top.active then
        m.stall.control = "stop"
        m.saver.control = "stop"
        return
    end if
    r = m.top.request
    if r = invalid then return
    m.pos = r.startAt
    m.dur = 0
    m.idx = 0
    m.list = []
    m.started = false
    m.cancelled = false
    m.everPlayed = false
    m.vid.visible = false
    m.msg.visible = true
    m.msg.text = "Finding a version to play..."
    m.top.setFocus(true)
    m.streamTask = CreateObject("roSGNode", "ApiTask")
    m.streamTask.op = "streams"
    m.streamTask.args = { type: r.type, id: r.id }
    m.streamTask.observeField("result", "onStreams")
    m.streamTask.control = "RUN"
end sub

sub onStreams(ev as object)
    if not ev.getRoSGNode().isSameNode(m.streamTask) then return
    r = ev.getData()
    if r = invalid or m.cancelled = true then return
    if r.streams = invalid
        m.msg.text = r.error + chr(10) + chr(10) + "Press Back."
        return
    end if
    m.list = r.streams
    m.idx = 0
    tryCurrent()
end sub

sub tryCurrent()
    if m.idx >= m.list.Count()
        m.vid.control = "stop"
        m.vid.visible = false
        m.msg.visible = true
        m.msg.text = "None of the versions would play on this Roku." + chr(10) + chr(10) + "Press Back."
        return
    end if
    s = m.list[m.idx]
    c = CreateObject("roSGNode", "ContentNode")
    c.url = s.url
    c.streamFormat = s.format
    c.title = m.top.request.name
    c.playStart = m.pos
    m.started = false
    m.msg.visible = true
    if m.idx = 0
        m.msg.text = "Starting..."
    else
        m.msg.text = "Trying another version (" + (m.idx + 1).ToStr() + " of " + m.list.Count().ToStr() + ")..."
    end if
    m.vid.visible = true
    m.vid.content = c
    m.vid.control = "play"
    m.stall.control = "start"
end sub

sub nextCandidate()
    m.stall.control = "stop"
    m.vid.control = "stop"
    m.idx = m.idx + 1
    tryCurrent()
end sub

sub onStall()
    if not m.started then nextCandidate()
end sub

sub onState()
    if m.cancelled = true then return
    s = m.vid.state
    if s = "playing"
        m.started = true
        m.everPlayed = true
        m.stall.control = "stop"
        m.msg.visible = false
        m.vid.setFocus(true)
        m.saver.control = "start"
    else if s = "error"
        if m.started
            ' it was playing and then broke: try the next version, starting from where it stopped
            m.started = false
            nextCandidate()
        else
            nextCandidate()
        end if
    else if s = "finished"
        m.pos = 0
        finish(true)
    end if
end sub

sub onPosition()
    p = m.vid.position
    if p > 0 then m.pos = p
end sub

sub onDuration()
    if m.vid.duration > 0 then m.dur = m.vid.duration
end sub

sub onSaveTick()
    if m.started then saveProgress()
end sub

sub saveProgress()
    r = m.top.request
    if r = invalid then return
    m.saveTask = CreateObject("roSGNode", "ApiTask")
    m.saveTask.op = "progress"
    m.saveTask.args = { type: r.type, videoId: r.id, root: r.root, name: r.name, poster: r.poster, pos: m.pos, dur: m.dur }
    m.saveTask.control = "RUN"
end sub

sub finish(watchedAll as boolean)
    m.cancelled = true
    m.stall.control = "stop"
    m.saver.control = "stop"
    m.vid.control = "stop"
    r = m.top.request
    if m.everPlayed = true and m.dur > 0 then saveProgress()
    at = m.pos
    if watchedAll then at = 0
    m.top.result = { videoId: r.id, pos: at, dur: m.dur }
    m.vid.visible = false
    m.top.done = true
end sub

function onKeyEvent(key as string, press as boolean) as boolean
    if press and key = "back"
        finish(false)
        return true
    end if
    return false
end function
