' Atrium on Roku: which screen is showing. Sign in -> Home -> Title -> Player, and Back goes the other way round.

sub init()
    m.signIn = m.top.findNode("signIn")
    m.home = m.top.findNode("home")
    m.detail = m.top.findNode("detail")
    m.player = m.top.findNode("player")
    m.signIn.observeField("signedIn", "onSignedIn")
    m.home.observeField("picked", "onPicked")
    m.home.observeField("signOutAsked", "onSignOut")
    m.detail.observeField("action", "onDetailAction")
    m.player.observeField("done", "onPlayerDone")
    if regRead("stremioKey") = "" then
        showSignIn()
    else
        showHome()
    end if
end sub

sub hideAll()
    m.signIn.active = false
    m.home.active = false
    m.detail.active = false
    m.player.active = false
    m.signIn.visible = false
    m.home.visible = false
    m.detail.visible = false
    m.player.visible = false
end sub

sub showSignIn()
    hideAll()
    m.signIn.visible = true
    m.signIn.active = true
end sub

sub showHome()
    hideAll()
    m.home.visible = true
    m.home.active = true
end sub

sub onSignedIn()
    if m.signIn.signedIn then showHome()
end sub

sub onSignOut()
    regWrite("stremioKey", "")
    showSignIn()
end sub

sub onPicked()
    p = m.home.picked
    if p = invalid then return
    m.detail.item = p
    hideAll()
    m.detail.visible = true
    m.detail.active = true
end sub

sub onDetailAction()
    a = m.detail.action
    if a = invalid then return
    if a.kind = "play"
        m.lastDetail = m.detail.item
        m.player.request = a
        hideAll()
        m.player.visible = true
        m.player.active = true
    else
        showHome()
    end if
end sub

sub onPlayerDone()
    ' back to the title page, which is still there; tell it where the player stopped
    if m.player.result <> invalid then m.detail.progress = m.player.result
    hideAll()
    m.detail.visible = true
    m.detail.active = true
end sub
