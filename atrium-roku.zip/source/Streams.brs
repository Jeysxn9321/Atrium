' Choosing which version of a title to play on a Roku.
' A Roku decodes H.264 everywhere, HEVC on most newer models, AAC / Dolby Digital sound, but not DTS or TrueHD (those play silent).
' So the list from Torrentio is scored and the best few are tried in turn.

function deviceCanHevc() as boolean
    ok = false
    try
        di = CreateObject("roDeviceInfo")
        r = di.CanDecodeVideo({ Codec: "hevc" })
        if r <> invalid and r.result = true then ok = true
    catch e
        ok = false
    end try
    return ok
end function

function sizeInGB(text as string) as float
    re = CreateObject("roRegex", "([0-9]+(?:\.[0-9]+)?)\s*(gb|mb)", "i")
    m = re.Match(text)
    if m.Count() < 3 then return 0
    v = Val(m[1])
    if LCase(m[2]) = "mb" then v = v / 1024
    return v
end function

function hasWord(text as string, pattern as string) as boolean
    re = CreateObject("roRegex", pattern, "i")
    return re.IsMatch(text)
end function

function streamScore(s as object, hevcOk as boolean) as integer
    name = asString(s.name)
    title = asString(s.title)
    t = LCase(name + " " + title)
    v = 0
    if hasWord(name, "\[tb\+\]|instant") then v = v + 1000
    if hasWord(t, "2160p|\b4k\b|\buhd\b") then
        v = v + 100
    else if hasWord(t, "1080p") then
        v = v + 300
    else if hasWord(t, "720p") then
        v = v + 200
    else if hasWord(t, "480p") then
        v = v + 50
    end if
    if hasWord(t, "\bcam\b|hdcam|camrip|telesync|hdts|\bts\b|\btc\b|\bscr\b|screener") then v = v - 3000
    if hasWord(t, "x264|h\.?264|\bavc\b") then v = v + 120
    if hasWord(t, "x265|h\.?265|hevc") then
        if hevcOk then v = v + 60 else v = v - 400
    end if
    if hasWord(t, "\baac\b") then v = v + 60
    if hasWord(t, "\bac-?3\b|\bdd5|\bdd\+|ddp|e-?ac-?3|dolby digital") then v = v + 40
    if hasWord(t, "\bdts\b|dts-hd|dts-x|truehd") then v = v - 250
    if hasWord(t, "remux") then v = v - 200
    if hasWord(t, "dolby vision|\bdv\b") then v = v - 400
    if hasWord(t, "\bhdr") then v = v - 120
    if hasWord(t, "\b3d\b") then v = v - 500
    if hasWord(t, "\b(ita|ger|german|spa|latino|rus|hindi|pol|tur|por|dublado)\b") and not hasWord(t, "\b(eng|english|multi)\b") then v = v - 150
    gb = sizeInGB(title)
    if gb > 12 then v = v - Int((gb - 12) * 10)
    return v
end function

' "mkv" or "mp4", from the address (the file name is its last part)
function streamFormat(url as string, hint as string) as string
    base = url
    q = Instr(1, base, "?")
    if q > 0 then base = Left(base, q - 1)
    l = LCase(base + " " + hint)
    if hasWord(l, "\.mp4\b|\.m4v\b") then return "mp4"
    return "mkv"
end function

' The playable versions, best first: [{ label, url, format, score }]
function pickStreams(streams as object, maxCount as integer) as object
    hevcOk = deviceCanHevc()
    list = []
    for each s in streams
        if type(s) = "roAssociativeArray" and s.url <> invalid and Left(asString(s.url), 8) = "https://"
            hint = ""
            if s.behaviorHints <> invalid and s.behaviorHints.filename <> invalid then hint = asString(s.behaviorHints.filename)
            label = replaceAll(asString(s.name), Chr(10), " ")
            list.Push({ label: label.Trim(), url: asString(s.url), format: streamFormat(asString(s.url), hint), score: streamScore(s, hevcOk) })
        end if
    end for
    ' sort by score, highest first (simple insertion sort: the lists are short)
    n = list.Count()
    for i = 1 to n - 1
        cur = list[i]
        j = i - 1
        while j >= 0 and list[j].score < cur.score
            list[j + 1] = list[j]
            j = j - 1
        end while
        list[j + 1] = cur
    end for
    out = []
    for i = 0 to n - 1
        if i < maxCount then out.Push(list[i])
    end for
    return out
end function

function replaceAll(text as string, find as string, repl as string) as string
    out = ""
    from = 1
    while true
        p = Instr(from, text, find)
        if p = 0 then exit while
        out = out + Mid(text, from, p - from) + repl
        from = p + Len(find)
    end while
    return out + Mid(text, from)
end function
