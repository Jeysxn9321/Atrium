' The sign-in code, the Roku way (message type 2). The phone does the same steps with WebCrypto (see shim.js: r2Keys, r2Send).
'
'   u1 = HMAC-SHA256(key = code, "atrium-roku-v2");  u(i) = HMAC-SHA256(key = code, u(i-1));  K = u(30000)
'   encKey = HMAC(K, "enc"), macKey = HMAC(K, "mac"), topic = "atrium-r2-" + first 24 hex digits of HMAC(K, "topic")
'   message = base64(iv) + "." + base64(AES-256-CBC(encKey, iv, json)) + "." + hex(HMAC(macKey, base64(iv) + "." + base64(ct)))

function asciiBytes(s as string) as object
    b = CreateObject("roByteArray")
    b.FromAsciiString(s)
    return b
end function

function hmacBytes(key as object, message as object) as object
    h = CreateObject("roHMAC")
    h.Setup("sha256", key)
    return h.Process(message)
end function

' Takes a few seconds (30000 rounds): call it from a Task.
function atriumDeriveKeys(code as string) as object
    h = CreateObject("roHMAC")
    h.Setup("sha256", asciiBytes(code))
    u = h.Process(asciiBytes("atrium-roku-v2"))
    for i = 2 to 30000
        u = h.Process(u)
    end for
    topic = LCase(hmacBytes(u, asciiBytes("topic")).ToHexString())
    return {
        enc: hmacBytes(u, asciiBytes("enc")),
        mac: hmacBytes(u, asciiBytes("mac")),
        topic: "atrium-r2-" + Left(topic, 24)
    }
end function

' Returns the decrypted JSON text, or "" when the message is not for us (wrong key, damaged, tampered).
function atriumDecrypt(message as string, keys as object) as string
    parts = message.Split(".")
    if parts.Count() <> 3 then return ""
    signed = parts[0] + "." + parts[1]
    want = LCase(hmacBytes(keys.mac, asciiBytes(signed)).ToHexString())
    if want <> LCase(parts[2]) then return ""
    iv = CreateObject("roByteArray")
    iv.FromBase64String(parts[0])
    ct = CreateObject("roByteArray")
    ct.FromBase64String(parts[1])
    if iv.Count() <> 16 or ct.Count() = 0 then return ""
    c = CreateObject("roEVPCipher")
    if c.Setup(false, "aes-256-cbc", keys.enc.ToHexString(), iv.ToHexString(), 1) <> 0 then return ""
    pt = c.Process(ct)
    if pt = invalid then return ""
    return pt.ToAsciiString()
end function
