' Atrium for Roku: helpers shared by the screens and the background tasks.

function regRead(key as string) as string
    sec = CreateObject("roRegistrySection", "atrium")
    if sec.Exists(key) then return sec.Read(key)
    return ""
end function

sub regWrite(key as string, value as string)
    sec = CreateObject("roRegistrySection", "atrium")
    if value = "" then
        sec.Delete(key)
    else
        sec.Write(key, value)
    end if
    sec.Flush()
end sub

' One web request, to be called from a Task thread. Returns { code, body } (code <= 0 means no answer).
function httpRequest(url as string, method = "GET" as string, body = "" as string, headers = invalid as object, timeoutMs = 20000 as integer) as object
    port = CreateObject("roMessagePort")
    x = CreateObject("roUrlTransfer")
    x.SetMessagePort(port)
    x.SetUrl(url)
    x.SetCertificatesFile("common:/certs/ca-bundle.crt")
    x.AddHeader("X-Roku-Reserved-Dev-Id", "")
    x.InitClientCertificates()
    x.EnableEncodings(true)
    if headers <> invalid
        for each k in headers
            x.AddHeader(k, headers[k])
        end for
    end if
    if method = "POST"
        started = x.AsyncPostFromString(body)
    else
        started = x.AsyncGetToString()
    end if
    if not started then return { code: -1, body: "" }
    msg = wait(timeoutMs, port)
    if msg = invalid
        x.AsyncCancel()
        return { code: -2, body: "" }
    end if
    if type(msg) = "roUrlEvent" then return { code: msg.GetResponseCode(), body: msg.GetString() }
    return { code: -3, body: "" }
end function

function getJson(url as string) as object
    r = httpRequest(url, "GET")
    if r.code <> 200 then return invalid
    return ParseJson(r.body)
end function

' A call to the Stremio account service. Returns the parsed answer, or invalid.
function stremioCall(method as string, payload as object) as object
    r = httpRequest("https://api.strem.io/api/" + method, "POST", FormatJson(payload), { "Content-Type": "application/json" })
    if r.code <> 200 then return invalid
    return ParseJson(r.body)
end function

' "1:23:45" or "23:45"
function formatClock(seconds as integer) as string
    if seconds < 0 then seconds = 0
    h = seconds \ 3600
    mi = (seconds mod 3600) \ 60
    s = seconds mod 60
    ms = mi.ToStr()
    if h > 0 and mi < 10 then ms = "0" + ms
    ss = s.ToStr()
    if s < 10 then ss = "0" + ss
    if h > 0 then return h.ToStr() + ":" + ms + ":" + ss
    return ms + ":" + ss
end function

function isoNow() as string
    d = CreateObject("roDateTime")
    return d.ToISOString()
end function

function asString(v as dynamic) as string
    if v = invalid then return ""
    t = type(v)
    if t = "roString" or t = "String" then return v
    if t = "roInt" or t = "Integer" or t = "roInteger" then return v.ToStr()
    if t = "roFloat" or t = "Float" or t = "roDouble" or t = "Double" then return Str(v).Trim()
    return ""
end function

function makeFont(size as integer, bold = false as boolean) as object
    f = CreateObject("roSGNode", "Font")
    if bold
        f.uri = "font:BoldSystemFont"
    else
        f.uri = "font:SystemFontFile"
    end if
    f.size = size
    return f
end function

' a one-off background request: runs op with args and calls onResult(result) on the owner's scope
function startApi(owner as object, op as string, args as object, callback as string) as object
    t = CreateObject("roSGNode", "ApiTask")
    t.op = op
    t.args = args
    t.observeField("result", callback)
    t.control = "RUN"
    return t
end function
